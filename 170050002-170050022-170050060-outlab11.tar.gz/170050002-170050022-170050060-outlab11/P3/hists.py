import csv
import numpy as np
import matplotlib.pyplot as plt

ess = np.zeros(28)
nic = np.zeros(28)
dcare = np.zeros(28)
useless = np.zeros(28)
topic = []

with open('survey_data.csv') as csvfile:
    reader = csv.reader(csvfile)
    count = 0

    for row in reader:
        if count == 0:
            for i in range(1,29) :
                if len(row[i]) > 31 :
                    topic.append(row[i][:30])
                else :
                    topic.append(row[i])
        else:
            for i in range(1,29):
                if row[i] == 'Essential':
                    ess[i-1] += 1
                elif row[i] == 'Nice to have':
                    nic[i-1] += 1
                elif row[i] == 'Dont care one way or another':
                    dcare[i-1] += 1
                elif row[i] == 'Utterly useless':
                    useless[i-1] += 1
        count += 1

arr = np.arange(28)
width = 0.50

plt.figure(figsize=(20,10))

plt1 = plt.bar(arr, ess, width, color="r")
plt2 = plt.bar(arr, nic, width, bottom=ess, color="g")
plt3 = plt.bar(arr, dcare, width, bottom=list(map(lambda x,y: x+y, ess, nic)), color="b")
plt4 = plt.bar(arr, useless, width, bottom=list(map(lambda x,y,z: x+y+z, ess, nic, dcare)), color="y")

plt.xticks(arr, topic, rotation = 90)
plt.yticks(np.arange(14))
# plt.grid(axis='y')
plt.title('Survey')
plt.xlabel('Topics')
plt.ylabel('Opinion of Faculty Members')

plt.legend((plt1[0], plt2[0], plt3[0], plt4[0]), ('Essential', 'Nice', 'Dont Care', 'Useless'))

# plt.tight_layout()
plt.gcf().subplots_adjust(bottom = 0.27)

# plt.show()
plt.savefig('hists.png')
# plt.show()