import numpy as np
import matplotlib.pyplot as plt
import csv
import math

with open('survey_data.csv') as csv_file:
    rows = csv.reader(csv_file, delimiter=',')
    flag = 0

    for row in rows:
        if flag == 0:
            topics = row[1:]
            reviews = [[] for i in range(1,len(row))]
            flag = 1

        else:
            count =0
            for x in row[1:]:
                reviews[count].append(x)
                count+=1
            
N = len(reviews)
indexes = np.arange(N)   
width = 0.3      
Essential = []
Nice = []
onewayorother = []
Utterly = []
values = []
entropies = []

total=len(reviews[0])



for review in reviews:
    essen = review.count('Essential')
    nic = review.count('Nice to have')
    oneway = review.count('Dont care one way or another')
    utter = review.count('Utterly useless')

    Essential.append(essen)
    Nice.append(nic)
    onewayorother.append(oneway)
    Utterly.append(utter)
    values.append(essen+nic+oneway+utter)
    temp = [essen/total , nic/total , oneway/total , utter/total] 
    entropy =0
    for i in temp:
        if i !=0:
            entropy+= i*math.log(i,2)
    entropies.append(-entropy)

temp = [[entropies[i] ,topics[i]] for i in range(N)]
temp.sort(key=lambda x : x[0])
finalentropies = [temp[i][0] for i in range(N)]
finaltopics = [temp[i][1] for i in range(N)]
# print(finaltopics)
finaltopics[0] = "bash shell Scripting"
finaltopics[-2] = "csh/tsh/zsh Shell Scripting"
for i in range(len(finaltopics)) :
    finaltopics[i] = finaltopics[i][:10] + '...' 
p = plt.bar(indexes, finalentropies, width,label = 'entropy')
plt.ylabel('Topics')
plt.title('Entropy Distribution')
# plt.legend('entropy',loc = 'upper left')
plt.xticks(indexes, finaltopics,rotation = 270)
plt.yticks(np.arange(0, max(finalentropies)+0.5, 0.2))
plt.show()
