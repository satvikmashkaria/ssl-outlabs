import sys
import numpy as np
from PIL import Image
import scipy.misc
# from matplotlib import pyplot as plt

def distance(a,b):
	if len(sys.argv) < 2:
		print("give atleast one argument")
		exit()
	else:
		if sys.argv[1] == "man":
			return abs(a[0]-b[0])+abs(a[1]-b[1])+abs(a[2]-b[2])
		elif sys.argv[1] == "eu":
			return ((a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2)**0.5
		else:
			print("Unknown option")
			exit()

filename = 'lake.png'
image = Image.open(filename)
arr = np.array(image,dtype='uint8')
lakemean = [np.mean(arr[:,:,0]) , np.mean(arr[:,:,1]) , np.mean(arr[:,:,2])]
image.close()

filename = 'builtup.png'
image = Image.open(filename)
arr = np.array(image,dtype='uint8')
builtupmean = [np.mean(arr[:,:,0]) , np.mean(arr[:,:,1]) , np.mean(arr[:,:,2])]
image.close()

totalsumr = 0
totalsumg = 0
totalsumb = 0
totalpixels = 0


for i in [1,2,3]:
	filename = "sea"+str(i)+".png"
	image = Image.open(filename)
	arr = np.array(image,dtype='uint8')
	totalpixels += np.shape(arr)[0]*np.shape(arr)[1]
	totalsumr += np.sum(arr[:,:,0])
	totalsumg += np.sum(arr[:,:,1])
	totalsumb += np.sum(arr[:,:,2])
	image.close()

seamean = [totalsumr/totalpixels , totalsumg/totalpixels , totalsumb/totalpixels]

totalsumr = 0
totalsumg = 0
totalsumb = 0
totalpixels = 0

for i in [1,2,3,4]:
	filename = "vegetation"+str(i)+".png"
	image = Image.open(filename)
	arr = np.array(image,dtype='uint8')
	totalpixels += np.shape(arr)[0]*np.shape(arr)[1]
	totalsumr += np.sum(arr[:,:,0])
	totalsumg += np.sum(arr[:,:,1])
	totalsumb += np.sum(arr[:,:,2])
	image.close()


vegetationmean = [totalsumr/totalpixels , totalsumg/totalpixels , totalsumb/totalpixels]

def finalvalue(a):
	lakedist = distance(a,lakemean)
	builtupdist = distance(a,builtupmean)
	seadist = distance(a,seamean)
	vegetationdist = distance(a,vegetationmean)
	mindist = min(lakedist,builtupdist,seadist,vegetationdist)

	if mindist == lakedist:
		return 75
	elif mindist == seadist:
		return 0
	elif mindist == builtupdist:
		return 255
	else:
		return 128

filename = 'mumbai.png'
image = Image.open(filename)
arr = np.array(image,dtype='uint8')
image.close()

ansarr = np.zeros([arr.shape[0],arr.shape[1]])

for i in range(0,arr.shape[0]):
	for j in range(0,arr.shape[1]):
		ansarr[i][j] = finalvalue(arr[i][j])

# I8 = (((ansarr - ansarr.min()) / (ansarr.max() - ansarr.min())) * 255.9).astype(np.uint8)
# img = Image.fromarray(I8)

if sys.argv[1] == "man":
	scipy.misc.imsave('segmented_man.png',ansarr)
else:
	scipy.misc.imsave('segmented_eu.png',ansarr)









