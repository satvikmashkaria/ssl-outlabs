from mpl_toolkits.mplot3d import Axes3D  
import matplotlib.pyplot as plt
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# n = 100
a = 2
b = 2
with open('3dpd.out','r') as f :
	lines = f.readlines()
	for line in lines:
		x = line.split(',')
		if a*float(x[2]) + b >= 0 :
			ax.scatter(float(x[0]),float(x[1]),float(x[2]),c='r')
		else :
			ax.scatter(float(x[0]),float(x[1]),float(x[2]),c='b')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

plt.show()